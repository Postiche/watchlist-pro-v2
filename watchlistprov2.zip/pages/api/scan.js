// API pour exécuter le scanner PEA
