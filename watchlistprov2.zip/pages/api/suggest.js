// API pour générer les idées IA chaque matin
