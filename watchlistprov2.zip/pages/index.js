// Frontend principal avec panel admin
