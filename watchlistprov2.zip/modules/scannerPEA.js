// Module de scan technique PEA (MM, RSI, breakouts, etc.)
