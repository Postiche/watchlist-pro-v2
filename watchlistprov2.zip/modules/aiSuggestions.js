// Suggestions IA quotidiennes (actions à surveiller, signaux forts)
