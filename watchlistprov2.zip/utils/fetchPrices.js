// Fonctions pour appeler les API financières en temps réel
