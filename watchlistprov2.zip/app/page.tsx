"use client"

import  from "../utils/fetchPrices"

export default function SyntheticV0PageForDeployment() {
  return < />
}